const puppeteer=require('puppeteer'); // including puppeteer "web browser manipulator"

const readline = require('readline').createInterface({
    input: process.stdin,
    output: process.stdout
  });

async function main(){
    
const browser= await puppeteer.launch({headless:false, slowMo:0});

const page= await browser.newPage();
await page.goto("https://www.instagram.com/");
//buttons=await page.$$("button");

//buttons= await page.$$eval("button",el=>{console.log(el);});
buttons= await page.$$("button");
console.log(buttons);  
let element;

for(i in buttons){
	let text=await page.evaluate(el=>el.textContent,buttons[i]);
    if(text.includes("Csak a")){
    
        element=buttons[i];
        console.log("megtaláltam!")
    }
    
    }

await element.click();

//wait for popup window to disappear and login inputs get visible
await page.waitForTimeout(2500);

let uname;
let pword;

uname= await new Promise(el=>{

    readline.question("Your E-mail/username please:",el);

});

pword= await new Promise(el=>{

    readline.question("Your password please:",el);

});

console.log("Your pw starts with "+pword.substring(0,2));

let elements= await page.$$("input[name=username]");
//console.log(elements);
await elements[0].type(uname);

elements= await page.$$("input[name=password]");
//console.log(elements);
await elements[0].type(pword);

elements=[];
elements = await page.$$("button[type=submit]");

await elements[0].click();

/**
 * -------------
 * -IF ELSE- FOR 2 STEP AUTH WHETHER IT IS ENABLED OR NOT
 * -------------
 */


/*
After click wait for page loading in otherwise the input for 2step auth wouldn't be found.
*/
await page.waitForNavigation({waitUntil: 'networkidle2'})

elements = await page.$$("input[name=verificationCode]");


authCode= await new Promise(el=>{

    readline.question("Your 2-step verification code:",el);

});

await elements[0].type(authCode);
 elements= await page.$$("button[type=button]");
await elements[0].click();
await page.waitForTimeout(2500);

//pressing don't save login credentials
elements= await page.$$("button");
//await elements[0].click();

for(i in elements){
	let text=await page.evaluate(el=>el.textContent,elements[i]);
   //console.log("\n"+text+"\n");
    if(text.includes("Most nem")){
    
        element=elements[i];
        console.log("megtaláltam! auth data");
    }
    
    }

await element.click();
await page.waitForTimeout(2500);

//pressing no for notifications
elements= await page.$$("button");


for(i in elements){
	let text=await page.evaluate(el=>el.textContent,elements[i]);
   //console.log("\n"+text+"\n");
    if(text.includes("Most nem")){
    
        element=elements[i];
        console.log("megtaláltam! notify");
    }
    
    }

await element.click();
await page.waitForTimeout(2500);
/**
 * 
 * from this point we are logged in
 * 
 */

//reading the given hashtags





/**
 * end of main
 **/

}

main();